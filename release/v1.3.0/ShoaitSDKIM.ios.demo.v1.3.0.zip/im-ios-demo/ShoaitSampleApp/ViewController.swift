//
//  ViewController.swift
//  ShoaitSampleApp
//
//  Created by Ulyness Chen on 2016/6/28.
//  Copyright © 2016年 III_SNSI. All rights reserved.
//

import UIKit
import ShoaitSDKiOS

class ViewController: UIViewController, UITextFieldDelegate, SMessageListener{
    
    
    let appid = "testapi"// need to change appid
    let IM = ShoaitIM.getInstance()
    let channelId = "-KJ4vvKeAZ0lOr2BfobO"
    
    @IBOutlet weak var accountText: UITextField!
    @IBOutlet weak var passwordText: UITextField!
    @IBOutlet weak var messageText: UITextField!
    @IBOutlet weak var loginBtn: UIButton!
    @IBOutlet weak var sendBtn: UIButton!
    @IBOutlet weak var textView: UITextView!
    
    @IBAction func clearBtn(sender: AnyObject) {
        textView.text = ""
    }
    @IBAction func loginBtn(sender: AnyObject) {
        if self.accountText.text!.isEmpty || self.passwordText.text!.isEmpty {
            let optionMenu = UIAlertController(title: nil, message: "登入錯誤", preferredStyle: .Alert)
            let cancelAction = UIAlertAction(title: "取消", style: .Cancel, handler: nil)
            optionMenu.addAction(cancelAction)
            
            self.presentViewController(optionMenu, animated: true, completion: nil)
            self.loginBtn.enabled = true
            return
        }
        
        loginBtn.enabled = false
        
        let mail = self.accountText.text?.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
        let password = self.passwordText.text?.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
        //let nameArr = mail!.componentsSeparatedByString("@")
        
        IM.login(mail, password: password) { (err, auth) -> Void in
            
            if auth != nil {
                print("login auth = \(auth?.uid)")

                let optionMenu = UIAlertController(title: nil, message: "登入成功", preferredStyle: .Alert)
                let cancelAction = UIAlertAction(title: "確定", style: .Cancel, handler: nil)
                optionMenu.addAction(cancelAction)
                
                self.presentViewController(optionMenu, animated: true, completion: nil)

                
                
                self.sendBtn.enabled = true
                self.messageText.enabled = true
                self.accountText.enabled = false
                self.passwordText.enabled = false
                
                self.IM.joinChannel(self.channelId) { (err) -> Void in
                    print("joinChannel err = \(err)")
                }
    
            } else {
                print("login err = \(err)")
                
                let optionMenu = UIAlertController(title: nil, message: "登入錯誤", preferredStyle: .Alert)
                let cancelAction = UIAlertAction(title: "取消", style: .Cancel, handler: nil)
                optionMenu.addAction(cancelAction)
                
                self.presentViewController(optionMenu, animated: true, completion: nil)
                self.loginBtn.enabled = true
            }
        }
    }
    
    @IBAction func sendBtn(sender: AnyObject) {
        if (self.messageText.text != nil) {
            let messageStr = self.messageText.text
            if (messageStr != "" && messageStr != "\n") {
                IM.send(SMessage(channelId: self.channelId, type: .TEXT, message: messageStr as String!))
                messageText.text = ""
                //self.textView.text = self.textView.text + (messageStr! + "\n")
            }
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        IM.initIM(appid)
        IM.addMessageListener(self)
        
        sendBtn.enabled = false
        messageText.enabled = false
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func onMessage(message: SMessage) {
        print("onMessage = \(message)")
        print("message.from = \(message.from)")
        
        if (message.from != "imserver") {
            print("message.id = \(message.id)")
            print("message.type = \(message.type)")
            print("message.message = \(message.message)")
            
            self.textView.text = self.textView.text + "\(message.from) : \(message.message)\n"
            
        }
        
    }
    
    func onMessageStatus(status: SMessageStatus) {
        print("onMessageStatus = \(status)")
    }
    
    override func touchesEnded(touches: Set<UITouch>, withEvent event: UIEvent?) {
        accountText.resignFirstResponder()
        passwordText.resignFirstResponder()
        messageText.resignFirstResponder()
    }
    
}

