package org.iii.demo.im.app;

import android.app.Application;
import android.app.NotificationManager;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import org.iii.demo.im.R;
import org.iii.demo.im.utility.Utility;
import org.iii.sdk.im.SMessage;
import org.iii.sdk.im.SMessageStatus;
import org.iii.sdk.im.ShoaitIM;
import org.iii.sdk.im.interfaces.SMessageListener;

public class MainApplication extends Application implements SMessageListener {

    private static final String DEBUG_TAG = "IM.DEMO";

    private final String mAppId = "testapi"; // 測試用 App Id

    public ShoaitIM mIm = ShoaitIM.getInstance();
    public boolean mIsForeground;

    @Override
    public void onCreate() {
        super.onCreate();
        mIm.init(this, mAppId);
        mIm.addMessageListener(this);
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
        mIm.removeMessageListener(this);
    }

    @Override
    public void onMessage(SMessage message) {
        if(mIsForeground == false) {
            String msg = message.getFrom() + " > " + message.getChannelId() + " : " + message.getMessage() + ", " + Utility.getFormatDate(message.getTimestamp(), null) + "\n";
            Log.d(DEBUG_TAG, "[MainApplication] " + msg);
            notifyMessage(message);
        }
    }

    @Override
    public void onMessageStatus(SMessageStatus status) {

    }

    public void notifyMessage(SMessage message){
        String msg = message.getFrom() + " > " + message.getChannelId() + " : " + message.getMessage() + ", " + Utility.getFormatDate(message.getTimestamp(), null) + "\n";

        NotificationManager mNotifyMgr = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationCompat.Builder mBuilder =
                new NotificationCompat.Builder(this)
                        .setSmallIcon(R.drawable.notification_icon)
                        .setContentTitle("訊息")
                        .setVibrate(new long[]{0, 300})
                        .setContentText(msg);

        mNotifyMgr.notify(0, mBuilder.build());
    }

}