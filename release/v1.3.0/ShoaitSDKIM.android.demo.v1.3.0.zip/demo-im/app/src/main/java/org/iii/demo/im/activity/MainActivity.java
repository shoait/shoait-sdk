package org.iii.demo.im.activity;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.iii.demo.im.R;
import org.iii.demo.im.app.MainApplication;
import org.iii.demo.im.utility.FileChooser;
import org.iii.demo.im.utility.Utility;
import org.iii.sdk.im.SAuthData;
import org.iii.sdk.im.SChannel;
import org.iii.sdk.im.SError;
import org.iii.sdk.im.SMessage;
import org.iii.sdk.im.SMessageStatus;
import org.iii.sdk.im.ShoaitIM;
import org.iii.sdk.im.interfaces.SCallback;
import org.iii.sdk.im.interfaces.SMessageListener;
import org.iii.sdk.im.interfaces.SProgressCallback;

import java.io.File;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;


public class MainActivity extends AppCompatActivity implements SMessageListener {

    private static final String DEBUG_TAG = "IM.DEMO";

    private final String mChannelId = "-KOtRHiOZG5iNVOfhflf"; // 測試用 Channel
    private final String mUserId = "demo1@shoait.com"; // 測試用帳號
    private final String mPwd = "12345678"; // 測試用密碼

    private MainApplication mApp;
    private ShoaitIM mIm;
    private String mUid;
    private FileChooser mFileChooser;
    private File cameraFile;
    private SChannel mChannel;

    private BroadcastReceiver mBroadcastReceiver;
    private IntentFilter mIntentFilter;


    private static final int REQ_TAKE_PHOTO = 0;
    private static final int REQ_TAKE_VIDEO = 1;


    @Bind(R.id.toolbar) Toolbar mToolbar;
    @Bind(R.id.info) TextView mInfo;
    @Bind(R.id.email) EditText mEmail;
    @Bind(R.id.password) EditText mPassword;
    @Bind(R.id.to) EditText mTo;
    @Bind(R.id.msg) EditText mMessage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        setSupportActionBar(mToolbar);
        mInfo.setText("");

        mApp = (MainApplication)getApplication();
        mIm = mApp.mIm;

        mEmail.setText(mUserId);
        mPassword.setText(mPwd);
        mTo.setText(mChannelId);

        mFileChooser = new FileChooser(this);

        addBroadcastAction();
    }


    @Override
    protected void onResume(){
        super.onResume();
        mApp.mIsForeground = true;
        mIm.addMessageListener(this);
        registerReceiver(mBroadcastReceiver, mIntentFilter);
    }

    @Override
    protected void onPause(){
        super.onPause();
        mApp.mIsForeground = false;
        mIm.removeMessageListener(this);
        //unregisterReceiver(mBroadcastReceiver);
    }

    @Override
    protected  void onDestroy(){
        super.onDestroy();
        mApp.mIsForeground = false;
        mIm.removeMessageListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        switch (id) {
            case R.id.action_clear:
                mInfo.setText("");
                break;
            case R.id.action_upload_img:
                uploadFile("image/*");
                break;
            case R.id.action_upload_video:
                uploadFile("video/*");
                break;
            case R.id.action_upload_file:
                uploadFile("application/*");
                break;
            case R.id.action_camera_img:
                openCamera(REQ_TAKE_PHOTO);
                break;
            case R.id.action_camera_video:
                openCamera(REQ_TAKE_VIDEO);
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * 登入
     */
    @OnClick(R.id.loginBtn)
    public void onLogin() {
        mIm.login(mEmail.getText().toString(), mPassword.getText().toString(), new SCallback<SError, SAuthData>() {

            @Override
            public void onCb(SError err, SAuthData data) {
                if (err != null) {
                    Toast.makeText(MainActivity.this, err.toString(), Toast.LENGTH_LONG).show();
                    Log.d(DEBUG_TAG, err.toString());
                    return;
                }
                mUid = data.getUid();
                Toast.makeText(MainActivity.this, data.toString() + " is ready", Toast.LENGTH_LONG).show();
                mInfo.append("\n登入成功: " + data.toString() + "\n");
                mToolbar.setTitle("uid: " + mUid);
                //createChannel();
                getCurChannel();
                join();
            }
        });
    }

    /**
     * 送訊息
     */
    @OnClick(R.id.sendBtn)
    public void onSend() {
        mIm.send(new SMessage(mChannel, SMessage.SMessageType.TEXT, mMessage.getText().toString()));
        mMessage.setText("");
        Utility.hideKeyboard(this);
    }

    /**
     * 收訊息
     * @param message 訊息包
     */
    @Override
    public void onMessage(final SMessage message) {
        String msg = "\n使用者: " + message.getFrom()
                + "\n送訊息到: " + message.getChannelId()
                + "\n訊息id: " + message.getId()
                + "\n內容: " + message.getMessage()
                + "\n時間: " + Utility.getFormatDate(message.getTimestamp(), null)  + "\n";
        Log.d(DEBUG_TAG, "[Message]" + msg);

        if(!message.getFrom().equals(mUid)) {
            mIm.setMessageStatus("已讀", message);
        }

        mInfo.append(msg);
    }

    /**
     * 收訊息狀態
     * @param status
     */
    @Override
    public void onMessageStatus(final SMessageStatus status) {
        Log.d(DEBUG_TAG, "[Message Status] " + status.toString());

        if(status.getUid().equals(mUid)) {
            return;
        }

        String msg = "\n訊息id: " + status.getMessageId()
                + "\n從使用者: " + status.getUid()
                + "\n訊息狀態: " + status.getStatus() + "\n";

        mInfo.append(msg);
    }


    private void uploadFile(String type){
        int sdk = android.os.Build.VERSION.SDK_INT;
        if(sdk >= Build.VERSION_CODES.M) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    0);
        }

        mFileChooser.showFileChooser(type);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (mFileChooser.onActivityResult(requestCode, resultCode, data)) {
            File[] files = mFileChooser.getChosenFiles();

            for (final File file : files) {
                final String mimeType = Utility.getMimeType(file.toURI().toString());
                Log.d(DEBUG_TAG, "[Upload File] file size = " + file.length() + "bytes");
                mIm.uploadFile(file, new SCallback<SError, String>() {
                    @Override
                    public void onCb(SError err, String data) {

                        if (err != null) {
                            Toast.makeText(MainActivity.this, err.toString(), Toast.LENGTH_LONG).show();
                            Log.e(DEBUG_TAG, err.toString());
                            return;
                        }
                        Log.d(DEBUG_TAG, "[Upload File] " + data);
                        mInfo.append("\n" + "[Upload File] " + data + "\n");

                        if(mimeType.contains("image/")){
                            mIm.send(new SMessage(mChannel, SMessage.SMessageType.IMAGE, data));
                        } else if(mimeType.contains("video/")){
                            mIm.send(new SMessage(mChannel, SMessage.SMessageType.VIDEO, data));
                        } else {
                            mIm.send(new SMessage(mChannel, SMessage.SMessageType.FILE, data + ":" + file.getName()));
                        }

                    }
                }, new SProgressCallback() {
                    @Override
                    public void onProgress(long progress, long total) {

                    }
                });
            }
        } else if(requestCode == REQ_TAKE_PHOTO) {

            if(resultCode == RESULT_OK) {
                Log.d(DEBUG_TAG, "[Upload File] file size = " + cameraFile.length() + "bytes");
                mIm.uploadFile(cameraFile, new SCallback<SError, String>() {
                    @Override
                    public void onCb(SError err, String data) {

                        if (err != null) {
                            Toast.makeText(MainActivity.this, err.toString(), Toast.LENGTH_LONG).show();
                            Log.e(DEBUG_TAG, err.toString());
                            return;
                        }
                        Log.d(DEBUG_TAG, "[Upload File] " + data);
                        mInfo.append("\n" + "[Upload File] " + data + "\n");
                        mIm.send(new SMessage(mTo.getText().toString(), SMessage.SMessageType.IMAGE, data));
                        cameraFile.delete();
                    }
                }, new SProgressCallback() {
                    @Override
                    public void onProgress(long progress, long total) {

                    }
                });
            }
        } else if(requestCode == REQ_TAKE_VIDEO) {

            if(resultCode == RESULT_OK) {
                Log.d(DEBUG_TAG, "[Upload File] file size = " + cameraFile.length() + "bytes");
                mIm.uploadFile(cameraFile, new SCallback<SError, String>() {
                    @Override
                    public void onCb(SError err, String data) {

                        if (err != null) {
                            Toast.makeText(MainActivity.this, err.toString(), Toast.LENGTH_LONG).show();
                            Log.e(DEBUG_TAG, err.toString());
                            return;
                        }
                        Log.d(DEBUG_TAG, "[Upload File] " + data);
                        mInfo.append("\n" + "[Upload File] " + data + "\n");
                        mIm.send(new SMessage(mTo.getText().toString(), SMessage.SMessageType.VIDEO, data));
                        cameraFile.delete();
                    }
                }, new SProgressCallback() {
                    @Override
                    public void onProgress(long progress, long total) {

                    }
                });

            }

        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    private void openCamera(int type){
        if(type == REQ_TAKE_PHOTO){
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cameraFile = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/camera.jpg");
            intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(cameraFile));
            startActivityForResult(intent, REQ_TAKE_PHOTO);
        } else if(type == REQ_TAKE_VIDEO){
            cameraFile = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/camera.mp4");
            Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(cameraFile));
            intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 0);
            startActivityForResult(intent, REQ_TAKE_VIDEO);
        }
    }

    private void createChannel(){
        if(mChannel != null) return;
        Set<String> uids = new HashSet<>();
        uids.add("friend user id");
        SChannel.create(uids, new SCallback<SError, SChannel>() {
            @Override
            public void onCb(SError err, SChannel channel) {
                if(err != null) {
                    Log.e(DEBUG_TAG, err.toString());
                    return;
                }

                mChannel = channel;
                mTo.setText(channel.getId());
                Log.d(DEBUG_TAG, "create channel : " + mChannel.getId());
            }
        });
    }

    private void join(){
        SChannel.join(mChannelId, new SCallback<SError, Map<String, String>>() {
            @Override
            public void onCb(SError err, Map<String, String> data) {
                if(err != null) {
                    Log.e(DEBUG_TAG, err.toString());
                }
                Log.d(DEBUG_TAG, data.toString());
            }
        });
    }

    private void getCurChannel(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    mChannel = mIm.getChannel(mChannelId);
                    if(mChannel != null) {
                        Log.d(DEBUG_TAG, "[Current Channel]" + mChannel.getId());
                        return;
                    }
                }
            }
        }).start();
    }

    private void addBroadcastAction() {
        mIntentFilter = new IntentFilter();
        mIntentFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
    }
}
