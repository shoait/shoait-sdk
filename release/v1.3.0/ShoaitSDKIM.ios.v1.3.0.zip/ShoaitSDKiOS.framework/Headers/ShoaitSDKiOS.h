//
//  ShoaitSDKiOS.h
//  ShoaitSDKiOS
//
//  Created by Ulyness Chen on 2016/6/27.
//  Copyright © 2016年 III_SNSI. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ShoaitSDKiOS.
FOUNDATION_EXPORT double ShoaitSDKiOSVersionNumber;

//! Project version string for ShoaitSDKiOS.
FOUNDATION_EXPORT const unsigned char ShoaitSDKiOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ShoaitSDKiOS/PublicHeader.h>


